package aspireinc.torture.Files.ServerStorage.humans;public class Trainer {
}
