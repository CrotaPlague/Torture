package aspireinc.torture.Files.ServerStorage;

public class boxReturn {
    public static int getBoxNum(int routeNum){
        int boxNum = routeNum;
        return boxNum;
    }
}
